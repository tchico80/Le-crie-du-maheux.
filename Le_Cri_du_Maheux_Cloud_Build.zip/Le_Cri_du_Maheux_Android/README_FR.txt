LE CRI DU MAHEUX — PROJET ANDROID 1.0

Ce dossier est le projet source Android Studio destiné à produire l'APK.
Il embarque le prototype HTML et les 5 fichiers MP3 dans les ressources de l'application.
L'application fonctionne hors ligne. Le lancement de la lecture reste déclenché par un appui utilisateur.

POUR CONSTRUIRE L'APK (sur un PC Windows/Mac/Linux):
1. Installer Android Studio et le JDK inclus.
2. Décompresser Le_Cri_du_Maheux_Android_Projet.zip.
3. Dans Android Studio, choisir Open et sélectionner le dossier Le_Cri_du_Maheux_Android.
4. Accepter la synchronisation Gradle et installer Android SDK Platform 35 si Android Studio le demande.
5. Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio affiche un lien vers app-debug.apk. Transférer ce fichier sur le Samsung et l'ouvrir pour installer.

IMPORTANT:
- Ceci est le projet source, pas un APK déjà compilé.
- La publication Google Play et l'achat unique nécessitent une configuration distincte (compte développeur, fiche Play, facturation Google Play et tests).
- Le code utilise un WebView local pour réutiliser l'interface validée dans Chrome.

COMPILATION DANS LE NUAGE SANS ORDINATEUR:
Le dossier .github/workflows contient un flux GitHub Actions pour compiler l'APK automatiquement.
Il faut un compte GitHub et téléverser le contenu de ce dossier dans un nouveau dépôt GitHub.
Ensuite, dans le dépôt: onglet Actions > Build APK - Le Cri du Maheux > Run workflow.
Quand la compilation est terminée: ouvrir le résultat du workflow, section Artifacts, puis télécharger Le-Cri-du-Maheux-APK.zip.
Décompresser ce ZIP sur le téléphone et ouvrir app-debug.apk pour l'installer.
Cette APK de test est signée en mode debug; elle n'est pas prête pour Google Play.
